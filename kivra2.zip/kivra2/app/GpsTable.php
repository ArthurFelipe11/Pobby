<?php

// GpsTable has been Depreciate since v2.4 (GPS data is now stored in delivery_guy_details table)

// namespace App;

// use Illuminate\Database\Eloquent\Model;

// class GpsTable extends Model
// {
//     public function order()
//     {
//         return $this->belongsTo('App\Order');
//     }
// }
