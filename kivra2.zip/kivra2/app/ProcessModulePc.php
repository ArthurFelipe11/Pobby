<?php

namespace App;

use Illuminate\Http\Request;
use Ixudra\Curl\Facades\Curl;
use Jenssegers\Agent\Agent;

class ProcessModulePc
{
    //
}
