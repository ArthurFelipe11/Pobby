<?php //00393
// Foodomaa� - Copyright � StackCanyon Technologies LLP - All Rights Reserved.
echo('<html> <style type="text/css"> <!-- body { font-family: Arial, Helvetica, sans-serif; font-size: 14px; text-decoration: none; text-align: center; background-color: #fafafa; } div#container { margin-top: 4rem; margin-left: auto; margin-right: auto; width: 550px; text-align: center; padding: 2rem; background-color: #fff; border-radius: 8px; box-shadow: rgba(0, 0, 0, 0.05) 0px 4px 12px; } --> </style> <title>Missing PHP Extension</title> <body> <div id="container"> <h2 align="center">Missing PHP Extension</h2> <p>ionCube Loader PHP extension is either not enabled or not installed on your server.</p>  <p> <a href="https://docs.foodomaa.com/extras/requirements-for-foodomaa#how-to-enable-php-extensions" target="_blank">Click Here</a> to learn how to enable PHP Extensions. </p></div></body> </html>');exit(199);

?>
HR+cPpxpo+YKM33FOKLUoxCFk76igz0vs5oZHU+QRJY0/sGBEO/LyabQqIXX7JtX1ghsNVUkHdG8
kxTneEKY0j4Zf7GZu6HsBCesmt3CozAROsyoZOGgznDAIcl0CbLyz1gPCJ/0/MkDYn3ixbWvUfoN
7Nq9PTX4jXWev+X/tdvhGX3DGvRuuFbCUDpNwt09NdHaTymLmp1YBBvz9xk59QyZMcgQ30I+rrU3
rNiP0G1EHcwgz6PmZQaT1acCguluJIdjH4KH6RNeRDOwz06GE3EldCpyCy5/P+/Vy+Pw1nV5lHDS
8Pk57F/u3B8CtfPgEQtcr+IQsvgKNVZhGJWxajmMkgdOcbKa43gTnGEmLWospc1zz4O2vaixxHv+
RlTDeAeUy9iI0sykIXWlj4+q3mlnjX0+ciLNlWoKi9OlAjLa7DSgRbLOqmcKq5x7CJupz/Jrqj8U
CsKU3bvfPH0K53d3UoaoAWev7tN+UGEq7zHNeyAddNvlKKtn8XXjZmPon3VtiSRWQG8dmFaMoZVs
b8KzKdxRBWwSgUii7MzUnPwzyxQwKerD9zygafqZNtRxrqXJxzLbiw6vlwC1bsUxDL0xYv/CiOg5
7CNNdoOZw5aN6O8uygJCc9s9ik+mo4Ww3YVxePYX6on+/q8PMSKxCJ6dJT9n1vrPYegs2XzQKJjw
CqYy1ddsV/0F6cARiCUKNi60UFuaRz8xVBeQgHShemVejAAPBMEy+cAG/u9n/U74P1x4NvUHIpNq
XkpGLfFq4oRHI46uG1UXbaI9BM/TKMo+UTfsLf9BWDFs5jJONWbtGG8bgz7xpsEh+ewImBH6b6YX
P8wp5NBJisxYsOHL+Vzh9FQmMZ9cOEc1KyjztE5/H+FHZRktHT/OdF6yRIRVsgk28J+X11kQV7Mn
/OSmZGvVaz+DGUjQ+4vPDnL41HrR4WEddZAgeA2NA92HmtkhzWmdMIcybUFRIRigKCH4eDIfNJfo
paNm7YR/xst9WlxzKixs7IMbwvg9KhyAXpZP/kDNqzK8yWISemQJ663bZPODfI7cG6HQoEM+RudF
E+kExYLKk+x6b7rcYqC8AJCG4NRWNz6nDubstMyL9D5qDlRe/OJNp2H/sCZ8b+wj2uHYIW/uqfGm
glCvz960onocUxKjsKsOcU2vqqkqGKUGzeE8dc+QvUlT55W5dFaT/xtODSBg0OuqW7NAKnl4/ifl
ZpZf5OKUGj1Kz+x7HlBXxZPqNrgyhMdPbMrb0DuSR9vZFbKcEYT+g+fyLd9Cr9lxi8OmeE2f1v10
l9pza4N1YkaT+U3h2+n8A1c6tDBjGg5+B0c5rIZrkhRO2VyMOmPYpfZauNMUuDCXlYF9D4VWKTGa
2KAqOYchjhOhp7aoY1sshktMprXCeufIwU092a6cKRqfMWxRHM8/fNG56x/PepT7JBnp8UEf4Zyu
Rz/reoP6pP6ZchwFZME+N6v9jp95/eIU3KK10MlNrNwh06pbhoqkRhJsIeRpaDf29VzBJhMVaUVw
8IB7WiguNXaDSLfU7VwHGMB7rMFvNx5rGGW2f3e+ZaKPIpWzQd6e4/TEgDmfInOCakRx0h3BqyFC
+ZbmTjs9ENj/MzouuXl/1z0SUqMDiRg7JgUpXOQPpj91kt7Ke8B7ghrWN4pcO8fUki90Abb73ugY
u3bqNxPg/nVwfS62Cd51L0gXQihNgjpm1I3nBgvAiGcmMjIRnc1IsFfN5doXVHib4mellc4CFytZ
Bwsv1DXHH67qhLoXE883uaenxWusxIxqxiWYR+rwEEMjxpPP92m+lSnRbCsepOC/UEwj6fy50TDj
DIMtt354MH/tfyM88Tgvj2BFT3ALmBSWcBnmLsOVtrPl4LvBNdRb2vO7oS4p07iFZK3oSf41q0bg
DU1fLPY1nrFWXx18roLVKq6bi4rxN4AYNP8fCbO9bfmLGbH91KM26GYLCw4Sw86qzVWKvbrnR981
D3RIOhr8mu3FutYUZBjfhBsNj2mLHpDWh+tqIpRRgc7J87qwdlqEIOG7yWp0bl1FFGTqBbZX3+FT
jGRzNVxQXFhYV9i5hpvkkzQYTe5ZHdYkpu6SGY6nFu16jjpZ59r1AfWTZNpNUDccCvlhOXnBvUIh
IMrlLtohAyR+p0/flyVXvrs52rGMkiQwqUEZYqD5YDVJ2ODJKjucAmiM057+myCC9qXx1mN54CcP
Xb0Icud2ZkAcRZyEbYorxwhmLf3lo25h25R/OMTMgIQjgk1GvhZOUgL+J7Lq7tfsQ7xMwUid9Stk
ABWIhJaQu5nFFp4DtCyTHKeHFOeYRATLxyDy