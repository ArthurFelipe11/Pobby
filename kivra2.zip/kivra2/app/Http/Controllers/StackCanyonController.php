<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StackCanyonController extends Controller
{
    public function start()
    {
        //
    }
}
