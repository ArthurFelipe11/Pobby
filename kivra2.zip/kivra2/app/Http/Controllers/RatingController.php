<?php

namespace App\Http\Controllers;

class RatingController extends Controller
{
    //
}
