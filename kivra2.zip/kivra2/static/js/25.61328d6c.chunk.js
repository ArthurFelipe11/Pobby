(window.webpackJsonp = window.webpackJsonp || []).push([
  [25],
  {
    244: function (e, t, a) {
      "use strict";
      a.d(t, "a", function () {
        return r;
      });
      var r = function (e, t) {
        var a;
        return function () {
          var r = this,
            n = arguments;
          clearTimeout(a),
            (a = setTimeout(function () {
              return e.apply(r, n);
            }, t));
        };
      };
    },
    343: function (e, t, a) {
      "use strict";
      a.r(t);
      var r = a(3),
        n = a(4),
        l = a(7),
        c = a(6),
        o = a(8),
        s = a(0),
        m = a.n(s),
        i = a(103),
        u = a(58),
        g = a(258),
        d = a(226),
        p = a(304),
        h = a.n(p),
        E = a(42),
        y = a(249),
        b = a(18),
        f = a.n(b),
        v = a(259),
        S = a(168),
        I = a(52),
        N = a.n(I),
        k = a(44),
        _ = a.n(k),
        x = a(16),
        F = (function (e) {
          function t() {
            var e, a;
            Object(r.a)(this, t);
            for (var n = arguments.length, o = new Array(n), s = 0; s < n; s++)
              o[s] = arguments[s];
            return (
              ((a = Object(l.a)(
                this,
                (e = Object(c.a)(t)).call.apply(e, [this].concat(o))
              )).forceStateUpdate = function () {
                setTimeout(function () {
                  a.forceUpdate(), a.props.update();
                }, 100);
              }),
              a
            );
          }
          return (
            Object(o.a)(t, e),
            Object(n.a)(t, [
              {
                key: "render",
                value: function () {
                  var e = this,
                    t = this.props,
                    a = t.addProduct,
                    r = t.removeProduct,
                    n = t.product,
                    l = t.cartProducts,
                    c = t.restaurant;
                  return (
                    (n.quantity = 1),
                    m.a.createElement(
                      m.a.Fragment,
                      null,
                      "true" === localStorage.getItem("recommendedLayoutV2")
                        ? m.a.createElement(
                            "div",
                            { key: n.id, className: "product-slider-item" },
                            m.a.createElement(
                              "div",
                              {
                                className:
                                  "block border-radius-275 recommended-item-shadow"
                              },
                              m.a.createElement(
                                "div",
                                {
                                  className:
                                    "block-content recommended-item-content py-5 mb-5",
                                  style: {
                                    position: "relative",
                                    height: "17.5rem"
                                  }
                                },
                                m.a.createElement(
                                  m.a.Fragment,
                                  null,
                                  m.a.createElement(
                                    S.a,
                                    { to: c.slug + "/" + n.id },
                                    m.a.createElement(
                                      _.a,
                                      null,
                                      m.a.createElement("img", {
                                        src: n.image,
                                        alt: n.name,
                                        className: "recommended-item-image"
                                      })
                                    )
                                  ),
                                  m.a.createElement(
                                    m.a.Fragment,
                                    null,
                                    void 0 !==
                                      l.find(function (e) {
                                        return e.id === n.id;
                                      }) &&
                                      m.a.createElement(
                                        N.a,
                                        { duration: 150 },
                                        m.a.createElement(
                                          "div",
                                          {
                                            className:
                                              "quantity-badge-recommended",
                                            style: {
                                              backgroundColor: localStorage.getItem(
                                                "storeColor"
                                              )
                                            }
                                          },
                                          m.a.createElement(
                                            "span",
                                            null,
                                            n.addon_categories.length
                                              ? m.a.createElement(
                                                  m.a.Fragment,
                                                  null,
                                                  m.a.createElement("i", {
                                                    className: "si si-check",
                                                    style: {
                                                      lineHeight: "1.3rem"
                                                    }
                                                  })
                                                )
                                              : m.a.createElement(
                                                  m.a.Fragment,
                                                  null,
                                                  l.find(function (e) {
                                                    return e.id === n.id;
                                                  }).quantity
                                                )
                                          )
                                        )
                                      )
                                  )
                                ),
                                m.a.createElement(
                                  "div",
                                  { className: "my-2 recommended-item-meta" },
                                  m.a.createElement(
                                    "div",
                                    {
                                      className:
                                        "px-5 text-left recommended-v2-ellipsis-meta"
                                    },
                                    "true" ===
                                      localStorage.getItem("showVegNonVegBadge")
                                      ? null !== n.is_veg &&
                                          m.a.createElement(
                                            "div",
                                            {
                                              className:
                                                "d-flex justify-content-between align-items-center"
                                            },
                                            n.is_veg
                                              ? m.a.createElement(
                                                  m.a.Fragment,
                                                  null,
                                                  m.a.createElement("img", {
                                                    src:
                                                      "/assets/img/various/veg-icon-bg.png",
                                                    alt: "Veg",
                                                    style: {
                                                      width: "1rem",
                                                      alignSelf: "center"
                                                    },
                                                    className: "mr-1 my-1"
                                                  }),
                                                  m.a.createElement(
                                                    "span",
                                                    { className: "meta-name" },
                                                    n.name
                                                  )
                                                )
                                              : m.a.createElement(
                                                  m.a.Fragment,
                                                  null,
                                                  m.a.createElement("img", {
                                                    src:
                                                      "/assets/img/various/non-veg-icon-bg.png",
                                                    alt: "Non-Veg",
                                                    style: {
                                                      width: "1rem",
                                                      alignSelf: "center"
                                                    },
                                                    className: "mr-1 my-1"
                                                  }),
                                                  m.a.createElement(
                                                    "span",
                                                    { className: "meta-name" },
                                                    n.name
                                                  )
                                                )
                                          )
                                      : m.a.createElement(
                                          "span",
                                          { className: "meta-name" },
                                          n.name
                                        )
                                  ),
                                  m.a.createElement(
                                    "div",
                                    { className: "ml-2" },
                                    m.a.createElement(
                                      "span",
                                      { className: "meta-price" },
                                      "true" ===
                                        localStorage.getItem(
                                          "hidePriceWhenZero"
                                        ) && "0.00" === n.price
                                        ? null
                                        : m.a.createElement(
                                            m.a.Fragment,
                                            null,
                                            n.old_price > 0 &&
                                              m.a.createElement(
                                                "span",
                                                {
                                                  className: "strike-text mr-1"
                                                },
                                                " ",
                                                "left" ===
                                                  localStorage.getItem(
                                                    "currencySymbolAlign"
                                                  ) &&
                                                  localStorage.getItem(
                                                    "currencyFormat"
                                                  ),
                                                " ",
                                                n.old_price,
                                                "right" ===
                                                  localStorage.getItem(
                                                    "currencySymbolAlign"
                                                  ) &&
                                                  localStorage.getItem(
                                                    "currencyFormat"
                                                  )
                                              ),
                                            m.a.createElement(
                                              "span",
                                              null,
                                              "left" ===
                                                localStorage.getItem(
                                                  "currencySymbolAlign"
                                                ) &&
                                                localStorage.getItem(
                                                  "currencyFormat"
                                                ),
                                              " ",
                                              n.price,
                                              "right" ===
                                                localStorage.getItem(
                                                  "currencySymbolAlign"
                                                ) &&
                                                localStorage.getItem(
                                                  "currencyFormat"
                                                )
                                            )
                                          )
                                    )
                                  ),
                                  m.a.createElement(
                                    "div",
                                    {
                                      className:
                                        "d-flex btn-group btn-group-sm my-5 btn-full justify-content-around",
                                      role: "group",
                                      "aria-label": "btnGroupIcons1",
                                      style: { height: "40px" }
                                    },
                                    n.is_active
                                      ? m.a.createElement(
                                          m.a.Fragment,
                                          null,
                                          n.addon_categories.length
                                            ? m.a.createElement(
                                                "button",
                                                {
                                                  disabled: !0,
                                                  type: "button",
                                                  className:
                                                    "btn btn-add-remove",
                                                  style: {
                                                    color: localStorage.getItem(
                                                      "cartColor-bg"
                                                    )
                                                  }
                                                },
                                                m.a.createElement(
                                                  "span",
                                                  { className: "btn-dec" },
                                                  "-"
                                                ),
                                                m.a.createElement(f.a, {
                                                  duration: "500"
                                                })
                                              )
                                            : m.a.createElement(
                                                "button",
                                                {
                                                  type: "button",
                                                  className:
                                                    "btn btn-add-remove",
                                                  style: {
                                                    color: localStorage.getItem(
                                                      "cartColor-bg"
                                                    )
                                                  },
                                                  onClick: function () {
                                                    r(n), e.forceStateUpdate();
                                                  }
                                                },
                                                m.a.createElement(
                                                  "span",
                                                  { className: "btn-dec" },
                                                  "-"
                                                ),
                                                m.a.createElement(f.a, {
                                                  duration: "500"
                                                })
                                              ),
                                          n.addon_categories.length
                                            ? m.a.createElement(y.a, {
                                                product: n,
                                                addProduct: a,
                                                update: this.props
                                                  .forceStateUpdate,
                                                forceUpdate: this
                                                  .forceStateUpdate
                                              })
                                            : m.a.createElement(
                                                "button",
                                                {
                                                  type: "button",
                                                  className:
                                                    "btn btn-add-remove",
                                                  style: {
                                                    color: localStorage.getItem(
                                                      "cartColor-bg"
                                                    )
                                                  },
                                                  onClick: function () {
                                                    a(n), e.forceStateUpdate();
                                                  }
                                                },
                                                m.a.createElement(
                                                  "span",
                                                  { className: "btn-inc" },
                                                  "+"
                                                ),
                                                m.a.createElement(f.a, {
                                                  duration: "500"
                                                })
                                              )
                                        )
                                      : m.a.createElement(
                                          "div",
                                          {
                                            className:
                                              "text-danger text-item-not-available d-flex align-items-center"
                                          },
                                          localStorage.getItem(
                                            "cartItemNotAvailable"
                                          )
                                        )
                                  )
                                )
                              )
                            )
                          )
                        : m.a.createElement(
                            "div",
                            {
                              key: n.id,
                              className:
                                "col-6 p-0 d-flex justify-content-center px-5"
                            },
                            m.a.createElement(
                              "div",
                              {
                                className:
                                  "block border-radius-275 recommended-item-shadow mb-3"
                              },
                              m.a.createElement(
                                "div",
                                {
                                  className:
                                    "block-content recommended-item-content py-5 mb-5"
                                },
                                m.a.createElement(
                                  S.a,
                                  { to: c.slug + "/" + n.id },
                                  m.a.createElement("img", {
                                    src: n.image,
                                    alt: n.name,
                                    className: "recommended-item-image"
                                  })
                                ),
                                m.a.createElement(
                                  m.a.Fragment,
                                  null,
                                  void 0 !==
                                    l.find(function (e) {
                                      return e.id === n.id;
                                    }) &&
                                    m.a.createElement(
                                      N.a,
                                      { duration: 150 },
                                      m.a.createElement(
                                        "div",
                                        {
                                          className:
                                            "quantity-badge-recommended",
                                          style: {
                                            backgroundColor: localStorage.getItem(
                                              "storeColor"
                                            )
                                          }
                                        },
                                        m.a.createElement(
                                          "span",
                                          null,
                                          n.addon_categories.length
                                            ? m.a.createElement(
                                                m.a.Fragment,
                                                null,
                                                m.a.createElement("i", {
                                                  className: "si si-check",
                                                  style: {
                                                    lineHeight: "1.3rem"
                                                  }
                                                })
                                              )
                                            : m.a.createElement(
                                                m.a.Fragment,
                                                null,
                                                l.find(function (e) {
                                                  return e.id === n.id;
                                                }).quantity
                                              )
                                        )
                                      )
                                    )
                                ),
                                m.a.createElement(
                                  "div",
                                  { className: "my-2 recommended-item-meta" },
                                  m.a.createElement(
                                    "div",
                                    { className: "px-5 text-left" },
                                    "true" ===
                                      localStorage.getItem(
                                        "showVegNonVegBadge"
                                      ) &&
                                      null !== n.is_veg &&
                                      m.a.createElement(
                                        m.a.Fragment,
                                        null,
                                        n.is_veg
                                          ? m.a.createElement("img", {
                                              src:
                                                "/assets/img/various/veg-icon-bg.png",
                                              alt: "Veg",
                                              style: { width: "1rem" },
                                              className: "mr-1"
                                            })
                                          : m.a.createElement("img", {
                                              src:
                                                "/assets/img/various/non-veg-icon-bg.png",
                                              alt: "Non-Veg",
                                              style: { width: "1rem" },
                                              className: "mr-1"
                                            })
                                      ),
                                    m.a.createElement(
                                      "span",
                                      { className: "meta-name" },
                                      n.name
                                    ),
                                    m.a.createElement("br", null),
                                    m.a.createElement(
                                      "span",
                                      { className: "meta-price" },
                                      "true" ===
                                        localStorage.getItem(
                                          "hidePriceWhenZero"
                                        ) && "0.00" === n.price
                                        ? null
                                        : m.a.createElement(
                                            m.a.Fragment,
                                            null,
                                            n.old_price > 0 &&
                                              m.a.createElement(
                                                "span",
                                                {
                                                  className: "strike-text mr-1"
                                                },
                                                " ",
                                                "left" ===
                                                  localStorage.getItem(
                                                    "currencySymbolAlign"
                                                  ) &&
                                                  localStorage.getItem(
                                                    "currencyFormat"
                                                  ),
                                                " ",
                                                n.old_price,
                                                "right" ===
                                                  localStorage.getItem(
                                                    "currencySymbolAlign"
                                                  ) &&
                                                  localStorage.getItem(
                                                    "currencyFormat"
                                                  )
                                              ),
                                            m.a.createElement(
                                              "span",
                                              null,
                                              "left" ===
                                                localStorage.getItem(
                                                  "currencySymbolAlign"
                                                ) &&
                                                localStorage.getItem(
                                                  "currencyFormat"
                                                ),
                                              " ",
                                              n.price,
                                              "right" ===
                                                localStorage.getItem(
                                                  "currencySymbolAlign"
                                                ) &&
                                                localStorage.getItem(
                                                  "currencyFormat"
                                                )
                                            ),
                                            n.old_price > 0 &&
                                              "true" ===
                                                localStorage.getItem(
                                                  "showPercentageDiscount"
                                                ) &&
                                              m.a.createElement(
                                                m.a.Fragment,
                                                null,
                                                m.a.createElement(
                                                  "span",
                                                  {
                                                    className:
                                                      "price-percentage-discount mb-0 ml-1",
                                                    style: {
                                                      color: localStorage.getItem(
                                                        "cartColorBg"
                                                      )
                                                    }
                                                  },
                                                  parseFloat(
                                                    ((parseFloat(n.old_price) -
                                                      parseFloat(n.price)) /
                                                      parseFloat(n.old_price)) *
                                                      100
                                                  ).toFixed(0),
                                                  localStorage.getItem(
                                                    "itemPercentageDiscountText"
                                                  )
                                                )
                                              )
                                          )
                                    ),
                                    n.addon_categories.length > 0 &&
                                      m.a.createElement(
                                        "span",
                                        {
                                          className:
                                            "ml-2 customizable-item-text",
                                          style: {
                                            color: localStorage.getItem(
                                              "storeColor"
                                            )
                                          }
                                        },
                                        localStorage.getItem(
                                          "customizableItemText"
                                        )
                                      )
                                  ),
                                  m.a.createElement(
                                    "div",
                                    {
                                      className:
                                        "d-flex btn-group btn-group-sm my-5 btn-full justify-content-around",
                                      role: "group",
                                      "aria-label": "btnGroupIcons1"
                                    },
                                    n.addon_categories.length
                                      ? m.a.createElement(
                                          "button",
                                          {
                                            disabled: !0,
                                            type: "button",
                                            className: "btn btn-add-remove",
                                            style: {
                                              color: localStorage.getItem(
                                                "cartColor-bg"
                                              )
                                            }
                                          },
                                          m.a.createElement(
                                            "span",
                                            { className: "btn-dec" },
                                            "-"
                                          ),
                                          m.a.createElement(f.a, {
                                            duration: "500"
                                          })
                                        )
                                      : m.a.createElement(
                                          "button",
                                          {
                                            type: "button",
                                            className: "btn btn-add-remove",
                                            style: {
                                              color: localStorage.getItem(
                                                "cartColor-bg"
                                              )
                                            },
                                            onClick: function () {
                                              r(n), e.forceStateUpdate();
                                            }
                                          },
                                          m.a.createElement(
                                            "span",
                                            { className: "btn-dec" },
                                            "-"
                                          ),
                                          m.a.createElement(f.a, {
                                            duration: "500"
                                          })
                                        ),
                                    n.addon_categories.length
                                      ? m.a.createElement(y.a, {
                                          product: n,
                                          addProduct: a,
                                          update: this.props.forceStateUpdate,
                                          forceUpdate: this.forceStateUpdate
                                        })
                                      : m.a.createElement(
                                          "button",
                                          {
                                            type: "button",
                                            className: "btn btn-add-remove",
                                            style: {
                                              color: localStorage.getItem(
                                                "cartColor-bg"
                                              )
                                            },
                                            onClick: function () {
                                              a(n), e.forceStateUpdate();
                                            }
                                          },
                                          m.a.createElement(
                                            "span",
                                            { className: "btn-inc" },
                                            "+"
                                          ),
                                          m.a.createElement(f.a, {
                                            duration: "500"
                                          })
                                        )
                                  )
                                )
                              )
                            )
                          )
                    )
                  );
                }
              }
            ]),
            t
          );
        })(s.Component);
      F.contextTypes = {
        router: function () {
          return null;
        }
      };
      var w = Object(x.b)(
          function (e) {
            return { cartProducts: e.cart.products };
          },
          { addProduct: d.a, removeProduct: d.c }
        )(F),
        C = a(305),
        L = a.n(C),
        O = a(113),
        T = a.n(O),
        P = a(244),
        j = (function (e) {
          function t() {
            var e, a;
            Object(r.a)(this, t);
            for (var n = arguments.length, o = new Array(n), s = 0; s < n; s++)
              o[s] = arguments[s];
            return (
              ((a = Object(l.a)(
                this,
                (e = Object(c.a)(t)).call.apply(e, [this].concat(o))
              )).state = {
                update: !0,
                items_backup: [],
                searching: !1,
                data: [],
                filterText: null,
                filter_items: [],
                items: [],
                queryLengthError: !1
              }),
              (a.forceStateUpdate = function () {
                setTimeout(function () {
                  a.forceUpdate(),
                    a.state.update
                      ? a.setState({ update: !1 })
                      : a.setState({ update: !0 });
                }, 100);
              }),
              (a.searchForItem = function (e) {
                a.searchItem(e.target.value);
              }),
              (a.searchItem = Object(P.a)(function (e) {
                e.length >= 3
                  ? (a.setState({ filterText: e }),
                    a.props.searchItem(
                      a.state.items,
                      e,
                      localStorage.getItem("itemSearchText"),
                      localStorage.getItem("itemSearchNoResultText")
                    ),
                    a.setState({ searching: !0, queryLengthError: !1 }))
                  : a.setState({ queryLengthError: !0 }),
                  0 === e.length &&
                    (a.setState({ filterText: null, queryLengthError: !1 }),
                    a.props.clearSearch(a.state.items_backup),
                    a.setState({ searching: !1 }));
              }, 500)),
              (a.inputFocus = function () {
                a.refs.searchGroup.classList.add("search-shadow-light");
              }),
              (a.handleClickOutside = function (e) {
                a.refs.searchGroup &&
                  !a.refs.searchGroup.contains(e.target) &&
                  a.refs.searchGroup.classList.remove("search-shadow-light");
              }),
              a
            );
          }
          return (
            Object(o.a)(t, e),
            Object(n.a)(
              t,
              [
                {
                  key: "componentDidMount",
                  value: function () {
                    document.addEventListener(
                      "mousedown",
                      this.handleClickOutside
                    );
                  }
                },
                {
                  key: "componentWillUnmount",
                  value: function () {
                    document.removeEventListener(
                      "mousedown",
                      this.handleClickOutside
                    );
                  }
                },
                {
                  key: "shouldComponentUpdate",
                  value: function (e, t) {
                    return t !== this.state.data;
                  }
                },
                {
                  key: "render",
                  value: function () {
                    var e = this,
                      t = this.props,
                      a = t.addProduct,
                      r = t.removeProduct,
                      n = t.cartProducts,
                      l = t.restaurant,
                      c = this.state.data;
                    return m.a.createElement(
                      m.a.Fragment,
                      null,
                      m.a.createElement(
                        "div",
                        { className: "col-12 mt-10" },
                        m.a.createElement(
                          "div",
                          {
                            className: "input-group",
                            ref: "searchGroup",
                            onClick: this.inputFocus
                          },
                          m.a.createElement("input", {
                            type: "text",
                            className: "form-control items-search-box",
                            placeholder: localStorage.getItem(
                              "itemSearchPlaceholder"
                            ),
                            onChange: this.searchForItem
                          }),
                          m.a.createElement(
                            "div",
                            { className: "input-group-append" },
                            m.a.createElement(
                              "span",
                              {
                                className:
                                  "input-group-text items-search-box-icon"
                              },
                              m.a.createElement("i", {
                                className: "si si-magnifier"
                              })
                            )
                          )
                        )
                      ),
                      m.a.createElement(
                        "div",
                        null,
                        this.state.queryLengthError &&
                          m.a.createElement(
                            "div",
                            { className: "auth-error" },
                            m.a.createElement(
                              "div",
                              { className: "" },
                              localStorage.getItem("searchAtleastThreeCharsMsg")
                            )
                          )
                      ),
                      m.a.createElement(
                        "div",
                        {
                          className: "bg-grey-light mt-20 ".concat(
                            l && !l.certificate ? "mb-100" : null
                          )
                        },
                        !this.state.searching &&
                          m.a.createElement(
                            "div",
                            { className: "px-5" },
                            c.recommended
                              ? null
                              : m.a.createElement(
                                  E.a,
                                  {
                                    height: 480,
                                    width: 400,
                                    speed: 1.2,
                                    primaryColor: "#f3f3f3",
                                    secondaryColor: "#ecebeb"
                                  },
                                  m.a.createElement("rect", {
                                    x: "10",
                                    y: "22",
                                    rx: "4",
                                    ry: "4",
                                    width: "185",
                                    height: "137"
                                  }),
                                  m.a.createElement("rect", {
                                    x: "10",
                                    y: "168",
                                    rx: "0",
                                    ry: "0",
                                    width: "119",
                                    height: "18"
                                  }),
                                  m.a.createElement("rect", {
                                    x: "10",
                                    y: "193",
                                    rx: "0",
                                    ry: "0",
                                    width: "79",
                                    height: "18"
                                  }),
                                  m.a.createElement("rect", {
                                    x: "212",
                                    y: "22",
                                    rx: "4",
                                    ry: "4",
                                    width: "185",
                                    height: "137"
                                  }),
                                  m.a.createElement("rect", {
                                    x: "212",
                                    y: "168",
                                    rx: "0",
                                    ry: "0",
                                    width: "119",
                                    height: "18"
                                  }),
                                  m.a.createElement("rect", {
                                    x: "212",
                                    y: "193",
                                    rx: "0",
                                    ry: "0",
                                    width: "79",
                                    height: "18"
                                  }),
                                  m.a.createElement("rect", {
                                    x: "10",
                                    y: "272",
                                    rx: "4",
                                    ry: "4",
                                    width: "185",
                                    height: "137"
                                  }),
                                  m.a.createElement("rect", {
                                    x: "10",
                                    y: "418",
                                    rx: "0",
                                    ry: "0",
                                    width: "119",
                                    height: "18"
                                  }),
                                  m.a.createElement("rect", {
                                    x: "10",
                                    y: "443",
                                    rx: "0",
                                    ry: "0",
                                    width: "79",
                                    height: "18"
                                  }),
                                  m.a.createElement("rect", {
                                    x: "212",
                                    y: "272",
                                    rx: "4",
                                    ry: "4",
                                    width: "185",
                                    height: "137"
                                  }),
                                  m.a.createElement("rect", {
                                    x: "212",
                                    y: "418",
                                    rx: "0",
                                    ry: "0",
                                    width: "119",
                                    height: "18"
                                  }),
                                  m.a.createElement("rect", {
                                    x: "212",
                                    y: "443",
                                    rx: "0",
                                    ry: "0",
                                    width: "79",
                                    height: "18"
                                  })
                                ),
                            c.recommended &&
                              c.recommended.length > 0 &&
                              m.a.createElement(
                                "h3",
                                {
                                  className: "px-10 py-10 recommended-text mb-0"
                                },
                                localStorage.getItem("itemsPageRecommendedText")
                              ),
                            m.a.createElement(
                              "div",
                              {
                                className:
                                  "true" ===
                                  localStorage.getItem("recommendedLayoutV2")
                                    ? "product-slider"
                                    : "row m-0"
                              },
                              c.recommended
                                ? c.recommended.map(function (t) {
                                    return m.a.createElement(w, {
                                      restaurant: l,
                                      shouldUpdate: e.state.update,
                                      update: e.forceStateUpdate,
                                      product: t,
                                      addProduct: a,
                                      removeProduct: r,
                                      key: t.id
                                    });
                                  })
                                : null
                            )
                          ),
                        c.items &&
                          Object.keys(c.items).map(function (t, o) {
                            return m.a.createElement(
                              "div",
                              { key: t, id: t + o },
                              m.a.createElement(
                                h.a,
                                {
                                  trigger: t,
                                  open:
                                    0 === o ||
                                    "true" ===
                                      localStorage.getItem(
                                        "expandAllItemMenu"
                                      ) ||
                                    e.props.menuClicked
                                },
                                c.items[t].map(function (t) {
                                  return m.a.createElement(
                                    m.a.Fragment,
                                    { key: t.id },
                                    m.a.createElement(
                                      "span",
                                      { className: "hidden" },
                                      (t.quantity = 1)
                                    ),
                                    m.a.createElement(
                                      "div",
                                      {
                                        className: "category-list-item",
                                        style: {
                                          display: "flex",
                                          justifyContent: "space-between"
                                        }
                                      },
                                      null !== t.image &&
                                        m.a.createElement(
                                          m.a.Fragment,
                                          null,
                                          m.a.createElement(
                                            S.a,
                                            { to: l.slug + "/" + t.id },
                                            m.a.createElement(
                                              m.a.Fragment,
                                              null,
                                              e.state.searching
                                                ? m.a.createElement("img", {
                                                    src: t.image,
                                                    alt: t.name,
                                                    className: "flex-item-image"
                                                  })
                                                : m.a.createElement(
                                                    _.a,
                                                    null,
                                                    m.a.createElement(
                                                      T.a,
                                                      {
                                                        src: t.image,
                                                        placeholder:
                                                          "/assets/img/various/blank-white.jpg"
                                                      },
                                                      function (e, a) {
                                                        return m.a.createElement(
                                                          "img",
                                                          {
                                                            style: {
                                                              opacity: a
                                                                ? "0.5"
                                                                : "1"
                                                            },
                                                            src: e,
                                                            alt: t.name,
                                                            className:
                                                              "flex-item-image"
                                                          }
                                                        );
                                                      }
                                                    )
                                                  ),
                                              void 0 !==
                                                n.find(function (e) {
                                                  return e.id === t.id;
                                                }) &&
                                                m.a.createElement(
                                                  m.a.Fragment,
                                                  null,
                                                  m.a.createElement(
                                                    "div",
                                                    {
                                                      style: {
                                                        position: "absolute",
                                                        top: "0"
                                                      }
                                                    },
                                                    m.a.createElement(
                                                      "div",
                                                      {
                                                        className:
                                                          "quantity-badge-list",
                                                        style: {
                                                          backgroundColor: localStorage.getItem(
                                                            "storeColor"
                                                          )
                                                        }
                                                      },
                                                      m.a.createElement(
                                                        "span",
                                                        null,
                                                        t.addon_categories
                                                          .length
                                                          ? m.a.createElement(
                                                              m.a.Fragment,
                                                              null,
                                                              m.a.createElement(
                                                                "i",
                                                                {
                                                                  className:
                                                                    "si si-check",
                                                                  style: {
                                                                    lineHeight:
                                                                      "1.3rem"
                                                                  }
                                                                }
                                                              )
                                                            )
                                                          : m.a.createElement(
                                                              m.a.Fragment,
                                                              null,
                                                              n.find(function (
                                                                e
                                                              ) {
                                                                return (
                                                                  e.id === t.id
                                                                );
                                                              }).quantity
                                                            )
                                                      )
                                                    )
                                                  )
                                                )
                                            ),
                                            "true" ===
                                              localStorage.getItem(
                                                "showVegNonVegBadge"
                                              ) &&
                                              null !== t.is_veg &&
                                              m.a.createElement(
                                                m.a.Fragment,
                                                null,
                                                t.is_veg
                                                  ? m.a.createElement("img", {
                                                      src:
                                                        "/assets/img/various/veg-icon-bg.png",
                                                      alt: "Veg",
                                                      className:
                                                        "mr-1 veg-non-veg-badge"
                                                    })
                                                  : m.a.createElement("img", {
                                                      src:
                                                        "/assets/img/various/non-veg-icon-bg.png",
                                                      alt: "Non-Veg",
                                                      className:
                                                        "mr-1 veg-non-veg-badge"
                                                    })
                                              )
                                          )
                                        ),
                                      m.a.createElement(
                                        "div",
                                        {
                                          className:
                                            null !== t.image
                                              ? "flex-item-name ml-12"
                                              : "flex-item-name"
                                        },
                                        null === t.image &&
                                          m.a.createElement(
                                            m.a.Fragment,
                                            null,
                                            "true" ===
                                              localStorage.getItem(
                                                "showVegNonVegBadge"
                                              ) &&
                                              null !== t.is_veg &&
                                              m.a.createElement(
                                                m.a.Fragment,
                                                null,
                                                t.is_veg
                                                  ? m.a.createElement("img", {
                                                      src:
                                                        "/assets/img/various/veg-icon-bg.png",
                                                      alt: "Veg",
                                                      className:
                                                        "mr-1 veg-non-veg-badge-noimage"
                                                    })
                                                  : m.a.createElement("img", {
                                                      src:
                                                        "/assets/img/various/non-veg-icon-bg.png",
                                                      alt: "Non-Veg",
                                                      className:
                                                        "mr-1 veg-non-veg-badge-noimage"
                                                    })
                                              )
                                          ),
                                        m.a.createElement(
                                          "span",
                                          { className: "item-name" },
                                          t.name
                                        ),
                                        " ",
                                        m.a.createElement(v.a, { item: t }),
                                        m.a.createElement(
                                          "span",
                                          { className: "item-price" },
                                          "true" ===
                                            localStorage.getItem(
                                              "hidePriceWhenZero"
                                            ) && "0.00" === t.price
                                            ? null
                                            : m.a.createElement(
                                                m.a.Fragment,
                                                null,
                                                t.old_price > 0 &&
                                                  m.a.createElement(
                                                    "span",
                                                    {
                                                      className:
                                                        "strike-text mr-1"
                                                    },
                                                    " ",
                                                    "left" ===
                                                      localStorage.getItem(
                                                        "currencySymbolAlign"
                                                      ) &&
                                                      localStorage.getItem(
                                                        "currencyFormat"
                                                      ),
                                                    " ",
                                                    t.old_price,
                                                    "right" ===
                                                      localStorage.getItem(
                                                        "currencySymbolAlign"
                                                      ) &&
                                                      localStorage.getItem(
                                                        "currencyFormat"
                                                      )
                                                  ),
                                                m.a.createElement(
                                                  "span",
                                                  null,
                                                  "left" ===
                                                    localStorage.getItem(
                                                      "currencySymbolAlign"
                                                    ) &&
                                                    localStorage.getItem(
                                                      "currencyFormat"
                                                    ),
                                                  " ",
                                                  t.price,
                                                  "right" ===
                                                    localStorage.getItem(
                                                      "currencySymbolAlign"
                                                    ) &&
                                                    localStorage.getItem(
                                                      "currencyFormat"
                                                    )
                                                ),
                                                t.old_price > 0 &&
                                                  "true" ===
                                                    localStorage.getItem(
                                                      "showPercentageDiscount"
                                                    )
                                                  ? m.a.createElement(
                                                      m.a.Fragment,
                                                      null,
                                                      m.a.createElement(
                                                        "p",
                                                        {
                                                          className:
                                                            "price-percentage-discount mb-0",
                                                          style: {
                                                            color: localStorage.getItem(
                                                              "cartColorBg"
                                                            )
                                                          }
                                                        },
                                                        parseFloat(
                                                          ((parseFloat(
                                                            t.old_price
                                                          ) -
                                                            parseFloat(
                                                              t.price
                                                            )) /
                                                            parseFloat(
                                                              t.old_price
                                                            )) *
                                                            100
                                                        ).toFixed(0),
                                                        localStorage.getItem(
                                                          "itemPercentageDiscountText"
                                                        )
                                                      )
                                                    )
                                                  : m.a.createElement(
                                                      "br",
                                                      null
                                                    )
                                              )
                                        ),
                                         m.a.createElement(
                                          "div",
                                          { className: "item-name2" },
                                          t.desc
                                        ),
                                        " ",/*
                                        null !== t.desc
                                          ? m.a.createElement(
                                              m.a.Fragment,
                                              null,
                                            // m.a.createElement(
                                              //  L.a,
                                                
                                             /* {
                                                  className:"mostrando",
                                                  lines: 1,
                                                  more: localStorage.getItem(
                                                    "showMoreButtonText"
                                                  ),
                                                  less: localStorage.getItem(
                                                    "showLessButtonText"
                                                  ),
                                                  anchorclassName:
                                                    "show-more ml-1"
                                                },*/
                                               /* m.a.createElement("div", {
                                                  dangerouslySetInnerHTML: {
                                                    __html: t.desc
                                                  }
                                                })*/
                                              
                                      ),
                                      m.a.createElement(
                                        "div",
                                        {
                                          className:
                                            "item-actions pull-right pb-0"
                                        },
                                        m.a.createElement(
                                          "div",
                                          {
                                            className: "btn-group btn-group-sm",
                                            role: "group",
                                            "aria-label": "btnGroupIcons1"
                                          },
                                          t.is_active
                                            ? m.a.createElement(
                                                m.a.Fragment,
                                                null,
                                                t.addon_categories.length
                                                  ? m.a.createElement(
                                                      "button",
                                                      {
                                                        disabled: !0,
                                                        type: "button",
                                                        className:
                                                          "btn btn-add-remove",
                                                        style: {
                                                          color: localStorage.getItem(
                                                            "cartColor-bg"
                                                          )
                                                        }
                                                      },
                                                      m.a.createElement(
                                                        "span",
                                                        {
                                                          className: "btn-dec"
                                                        },
                                                        "-"
                                                      ),
                                                      m.a.createElement(f.a, {
                                                        duration: "500"
                                                      })
                                                    )
                                                  : m.a.createElement(
                                                      "button",
                                                      {
                                                        type: "button",
                                                        className:
                                                          "btn btn-add-remove",
                                                        style: {
                                                          color: localStorage.getItem(
                                                            "cartColor-bg"
                                                          )
                                                        },
                                                        onClick: function () {
                                                          (t.quantity = 1),
                                                            r(t),
                                                            e.forceStateUpdate();
                                                        }
                                                      },
                                                      m.a.createElement(
                                                        "span",
                                                        {
                                                          className: "btn-dec"
                                                        },
                                                        "-"
                                                      ),
                                                      m.a.createElement(f.a, {
                                                        duration: "500"
                                                      })
                                                    ),
                                                t.addon_categories.length
                                                  ? m.a.createElement(y.a, {
                                                      product: t,
                                                      addProduct: a,
                                                      forceUpdate:
                                                        e.forceStateUpdate
                                                    })
                                                  : m.a.createElement(
                                                      "button",
                                                      {
                                                        type: "button",
                                                        className:
                                                          "btn btn-add-remove",
                                                        style: {
                                                          color: localStorage.getItem(
                                                            "cartColor-bg"
                                                          )
                                                        },
                                                        onClick: function () {
                                                          a(t),
                                                            e.forceStateUpdate();
                                                        }
                                                      },
                                                      m.a.createElement(
                                                        "span",
                                                        {
                                                          className: "btn-inc"
                                                        },
                                                        "+"
                                                      ),
                                                      m.a.createElement(f.a, {
                                                        duration: "500"
                                                      })
                                                    )
                                              )
                                            : m.a.createElement(
                                                "div",
                                                {
                                                  className:
                                                    "text-danger text-item-not-available"
                                                },
                                                localStorage.getItem(
                                                  "cartItemNotAvailable"
                                                )
                                              )
                                        ),
                                        t.addon_categories.length > 0 &&
                                          m.a.createElement(
                                            m.a.Fragment,
                                            null,
                                            m.a.createElement(
                                              "span",
                                              {
                                                className:
                                                  "customizable-item-text d-block text-center",
                                                style: {
                                                  color: localStorage.getItem(
                                                    "storeColor"
                                                  )
                                                }
                                              },
                                              localStorage.getItem(
                                                "customizableItemText"
                                              )
                                            ),
                                            m.a.createElement("br", null)
                                          )
                                      )
                                    )
                                  );
                                })
                              )
                            );
                          }),
                        m.a.createElement("div", { className: "mb-50" })
                      )
                    );
                  }
                }
              ],
              [
                {
                  key: "getDerivedStateFromProps",
                  value: function (e, t) {
                    if (e.data !== t.data) {
                      if (null !== t.filterText) return { data: e.data };
                      if (null === t.filterText)
                        return {
                          items_backup: e.data,
                          data: e.data,
                          filter_items: e.data.items
                        };
                    }
                    if (e.restaurant_backup_items && t.items >= 0) {
                      var a = [];
                      return (
                        e.restaurant_backup_items.hasOwnProperty("items") &&
                          Object.keys(e.restaurant_backup_items.items).forEach(
                            function (t) {
                              e.restaurant_backup_items.items[t].forEach(
                                function (e) {
                                  a.push(e);
                                }
                              );
                            }
                          ),
                        { items: a }
                      );
                    }
                    return null;
                  }
                }
              ]
            ),
            t
          );
        })(s.Component),
        U = Object(x.b)(
          function (e) {
            return { cartProducts: e.cart.products };
          },
          {
            addProduct: d.a,
            removeProduct: d.c,
            searchItem: u.k,
            clearSearch: u.a
          }
        )(j),
        V = a(43),
        A = a(356),
        B = a(238),
        D = a(78),
        q = a.n(D),
        M = a(33),
        R = a(27),
        G = (function (e) {
          function t() {
            var e, a;
            Object(r.a)(this, t);
            for (var n = arguments.length, o = new Array(n), s = 0; s < n; s++)
              o[s] = arguments[s];
            return (
              ((a = Object(l.a)(
                this,
                (e = Object(c.a)(t)).call.apply(e, [this].concat(o))
              )).state = {
                is_active: 1,
                loading: !0,
                menuListOpen: !1,
                menuClicked: !1
              }),
              (a.handleMenuOpen = function () {
                a.setState({ menuListOpen: !0 }),
                  document
                    .getElementsByTagName("html")[0]
                    .classList.add("noscroll"),
                  document
                    .getElementsByTagName("body")[0]
                    .classList.add("noscroll");
              }),
              (a.handleClickOutside = function (e) {
                a.refs.menuItemBlock &&
                  !a.refs.menuItemBlock.contains(e.target) &&
                  (document
                    .getElementsByTagName("html")[0]
                    .classList.remove("noscroll"),
                  document
                    .getElementsByTagName("body")[0]
                    .classList.remove("noscroll"),
                  a.setState({ menuListOpen: !1 }));
              }),
              (a.handleMenuItemClick = function (e) {
                a.setState({ menuClicked: !0 });
                var t = document.getElementById(e.currentTarget.dataset.name);
                setTimeout(
                  function () {
                    t.scrollIntoView(),
                      window.scrollBy(0, -40),
                      a.setState({ menuListOpen: !1 }),
                      document
                        .getElementsByTagName("html")[0]
                        .classList.remove("noscroll"),
                      document
                        .getElementsByTagName("body")[0]
                        .classList.remove("noscroll");
                  },
                  a.state.menuClicked ? 0 : 500
                );
              }),
              a
            );
          }
          return (
            Object(o.a)(t, e),
            Object(n.a)(t, [
              {
                key: "componentDidMount",
                value: function () {
                  var e = this;
                  this.props.getSettings(), this.props.getAllLanguages();
                  var t = this.props.user.success
                    ? this.props.getRestaurantInfoForLoggedInUser(
                        this.props.restaurant
                      )
                    : this.props.getRestaurantInfo(this.props.restaurant);
                  t &&
                    t.then(function (t) {
                      t &&
                        (t.payload.id
                          ? e.props.getRestaurantItems(e.props.restaurant)
                          : e.context.router.history.push("/"),
                        1 === t.payload.delivery_type &&
                          localStorage.setItem("userSelected", "DELIVERY"),
                        2 === t.payload.delivery_type &&
                          localStorage.setItem("userSelected", "SELFPICKUP"),
                        3 === t.payload.delivery_type &&
                          "DELIVERY" ===
                            localStorage.getItem("userPreferredSelection") &&
                          localStorage.setItem("userSelected", "DELIVERY"),
                        3 === t.payload.delivery_type &&
                          "SELFPICKUP" ===
                            localStorage.getItem("userPreferredSelection") &&
                          localStorage.setItem("userSelected", "SELFPICKUP"),
                        "undefined" === t.payload.is_active &&
                          e.setState({ loading: !0 }),
                        (1 !== t.payload.is_active &&
                          0 !== t.payload.is_active) ||
                          (e.setState({ loading: !1 }),
                          e.setState({ is_active: t.payload.is_active })));
                    }),
                    null === localStorage.getItem("userSelected") &&
                      localStorage.setItem("userSelected", "DELIVERY"),
                    document.addEventListener(
                      "mousedown",
                      this.handleClickOutside
                    );
                }
              },
              {
                key: "componentWillReceiveProps",
                value: function (e) {
                  if (
                    (this.state.is_active ||
                      document
                        .getElementsByTagName("html")[0]
                        .classList.add("page-inactive"),
                    this.props.languages !== e.languages)
                  )
                    if (localStorage.getItem("userPreferedLanguage"))
                      this.props.getSingleLanguageData(
                        localStorage.getItem("userPreferedLanguage")
                      );
                    else if (e.languages.length) {
                      var t = e.languages.filter(function (e) {
                        return 1 === e.is_default;
                      })[0].id;
                      this.props.getSingleLanguageData(t);
                    }
                }
              },
              {
                key: "componentWillUnmount",
                value: function () {
                  document.removeEventListener(
                    "mousedown",
                    this.handleClickOutside
                  ),
                    document
                      .getElementsByTagName("html")[0]
                      .classList.remove("page-inactive");
                }
              },
              {
                key: "render",
                value: function () {
                  var e = this;
                  return window.innerWidth > 768
                    ? m.a.createElement(A.a, { to: "/" })
                    : m.a.createElement(
                        m.a.Fragment,
                        null,
                        m.a.createElement(V.a, {
                          seotitle: ""
                            .concat(this.props.restaurant_info.name, " | ")
                            .concat(localStorage.getItem("seoMetaTitle")),
                          seodescription: localStorage.getItem(
                            "seoMetaDescription"
                          ),
                          ogtype: "website",
                          ogtitle: ""
                            .concat(this.props.restaurant_info.name, " | ")
                            .concat(localStorage.getItem("seoOgTitle")),
                          ogdescription: localStorage.getItem(
                            "seoOgDescription"
                          ),
                          ogurl: window.location.href,
                          twittertitle: ""
                            .concat(this.props.restaurant_info.name, " | ")
                            .concat(localStorage.getItem("seoTwitterTitle")),
                          twitterdescription: localStorage.getItem(
                            "seoTwitterDescription"
                          )
                        }),
                        m.a.createElement(
                          "div",
                          { key: this.props.restaurant },
                          m.a.createElement(B.a, {
                            history: this.props.history,
                            restaurant: this.props.restaurant_info,
                            withLinkToRestaurant: !1
                          }),
                          m.a.createElement(U, {
                            data: this.props.restaurant_items,
                            restaurant: this.props.restaurant_info,
                            menuClicked: this.state.menuClicked,
                            shouldItemsListUpdate: localStorage.getItem(
                              "cleared"
                            ),
                            restaurant_backup_items: this.props
                              .restaurant_backup_items
                          })
                        ),
                        this.props.restaurant_info.certificate &&
                          m.a.createElement(
                            "div",
                            {
                              className: "mb-100 text-center certificate-code"
                            },
                            localStorage.getItem("certificateCodeText"),
                            " ",
                            this.props.restaurant_info.certificate
                          ),
                        m.a.createElement(
                          "div",
                          null,
                          !this.state.loading &&
                            m.a.createElement(
                              m.a.Fragment,
                              null,
                              this.state.is_active
                                ? m.a.createElement(g.a, null)
                                : m.a.createElement(
                                    "div",
                                    { className: "auth-error no-click" },
                                    m.a.createElement(
                                      "div",
                                      { className: "error-shake" },
                                      localStorage.getItem(
                                        "notAcceptingOrdersMsg"
                                      )
                                    )
                                  )
                            )
                        ),
                        m.a.createElement(
                          "div",
                          { className: "menu-list-container" },
                          this.state.menuListOpen
                            ? m.a.createElement(
                                m.a.Fragment,
                                null,
                                m.a.createElement("div", {
                                  className: "menu-open-backdrop"
                                }),
                                m.a.createElement(
                                  "div",
                                  {
                                    className: "menu-items-block",
                                    ref: "menuItemBlock"
                                  },
                                  m.a.createElement(
                                    "div",
                                    { 
                                    className: "menu-item-block-inner" 
                                    },
                                      m.a.createElement("img", {
                                src: this.props.restaurant.image3,
                                alt: t.name,
                                className: "restaurant-image2"
                            }),
                                    this.props.restaurant_items.items &&
                                      m.a.createElement(
                                        m.a.Fragment,
                                        null,
                                        Object.keys(
                                          this.props.restaurant_items.items
                                        ).map(function (t, a) {
                                          return m.a.createElement(
                                            "div",
                                            {
                                              className:
                                                "menu-item-block-single",
                                              key: t,
                                              onClick: e.handleMenuItemClick,
                                              "data-name": t + a
                                            },
                                            m.a.createElement(
                                              N.a,
                                              { bottom: !0, duration: 150 * a },
                                              m.a.createElement(
                                                "div",
                                                {
                                                  className:
                                                    "menu-item-block-single-name"
                                                },
                                                t
                                              ),
                                              m.a.createElement(
                                                "div",
                                                {
                                                  className:
                                                    "menu-item-block-single-quantity"
                                                },
                                                Object.keys(
                                                  e.props.restaurant_items
                                                    .items[t]
                                                ).length
                                              )
                                            )
                                          );
                                        })
                                      )
                                  )
                                )
                              )
                            : m.a.createElement(
                                "div",
                                {
                                  className: "menu-button-block-main",
                                  onClick: this.handleMenuOpen,
                                  style: {
                                    bottom:
                                      this.props.cartTotal.productQuantity > 0
                                        ? "5rem"
                                        : "2rem"
                                  }
                                },
                                m.a.createElement(
                                  q.a,
                                  { bottom: !0 },
                                  m.a.createElement(
                                    "button",
                                    {
                                      className: "btn btn-menu-list",
                                      style: {
                                        backgroundColor: localStorage.getItem(
                                          "storeColor"
                                        )
                                      }
                                    },
                                    m.a.createElement("i", {
                                      className: "si si-list mr-1"
                                    }),
                                    " ",
                                    localStorage.getItem("itemsMenuButtonText"),
                                    m.a.createElement(f.a, {
                                      duration: "500",
                                      hasTouch: !1
                                    })
                                  )
                                )
                              )
                        )
                      );
                }
              }
            ]),
            t
          );
        })(s.Component);
      G.contextTypes = {
        router: function () {
          return null;
        }
      };
      var W = Object(x.b)(
          function (e) {
            return {
              restaurant_info: e.items.restaurant_info,
              restaurant_items: e.items.restaurant_items,
              cartTotal: e.total.data,
              settings: e.settings.settings,
              languages: e.languages.languages,
              language: e.languages.language,
              user: e.user.user,
              restaurant_backup_items: e.items.restaurant_backup_items
            };
          },
          {
            getRestaurantInfo: u.b,
            getRestaurantItems: u.f,
            getSettings: M.a,
            getAllLanguages: R.a,
            getSingleLanguageData: R.b,
            getRestaurantInfoForLoggedInUser: u.e
          }
        )(G),
        z = (function (e) {
          function t() {
            return (
              Object(r.a)(this, t),
              Object(l.a)(this, Object(c.a)(t).apply(this, arguments))
            );
          }
          return (
            Object(o.a)(t, e),
            Object(n.a)(t, [
              {
                key: "render",
                value: function () {
                  return m.a.createElement(
                    m.a.Fragment,
                    null,
                    window.innerWidth >= 768
                      ? m.a.createElement(i.a, {
                          restaurant: this.props.match.params.restaurant
                        })
                      : m.a.createElement(W, {
                          restaurant: this.props.match.params.restaurant,
                          history: this.props.history
                        })
                  );
                }
              }
            ]),
            t
          );
        })(s.Component);
      t.default = z;
    }
  }
]);
